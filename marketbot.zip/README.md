# Market Research Bot AI

Google Sheet: https://docs.google.com/spreadsheets/d/1dIlm0r8OwST0gqK1wHwItpfbkA4tQS0cMHfCxi1KYwI/copy

Setup steps:
1. Upload repo
2. Add secrets
3. Run Actions
